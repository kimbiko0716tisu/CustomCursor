package com.example.customcursor;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final String NAME = "cursor_prefs";
    public static final String CURSOR_VISIBLE = "cursor_visible";
    public static final String PAD_ENABLED = "pad_enabled";
    public static final String PAD_EXPANDED = "pad_expanded";
    public static final String MOUSE_MODE = "mouse_mode";
    public static final String SIZE_DP = "size_dp";
    public static final String OPACITY = "opacity";
    public static final String SPEED = "speed";
    public static final String PAD_HEIGHT_DP = "pad_height_dp";
    public static final String IMAGE_VERSION = "image_version";
    public static final String IMAGE_FILE = "cursor.png";
    public static final String ANI_FILE = "cursor.ani";

    private Prefs() {
    }

    public static SharedPreferences get(Context context) {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }
}
