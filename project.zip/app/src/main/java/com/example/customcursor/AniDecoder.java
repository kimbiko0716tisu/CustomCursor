package com.example.customcursor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;
import java.util.List;

/** Reads Windows animated cursors (.ani) and single cursors/icons (.cur, .ico). */
public final class AniDecoder {

    public static final class Result {
        public Bitmap[] stepBitmaps;
        public int[] stepDelays; // milliseconds
        public int hotX;
        public int hotY;
    }

    private static final class Frame {
        Bitmap bmp;
        int hotX;
        int hotY;
    }

    private AniDecoder() {
    }

    private static int u16(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
    }

    private static int i32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8)
                | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }

    private static boolean tag(byte[] b, int o, String s) {
        if (o < 0 || o + 4 > b.length) return false;
        for (int i = 0; i < 4; i++) {
            if (b[o + i] != (byte) s.charAt(i)) return false;
        }
        return true;
    }

    /** Returns null if the data is not a supported .ani/.cur/.ico file. */
    public static Result decode(byte[] d) {
        try {
            if (d == null || d.length < 12) return null;
            if (tag(d, 0, "RIFF") && tag(d, 8, "ACON")) return decodeAni(d);
            if (u16(d, 0) == 0 && (u16(d, 2) == 1 || u16(d, 2) == 2)) {
                Frame f = decodeIco(d, 0, d.length);
                if (f == null) return null;
                Result r = new Result();
                r.stepBitmaps = new Bitmap[]{f.bmp};
                r.stepDelays = new int[]{1000};
                r.hotX = f.hotX;
                r.hotY = f.hotY;
                return r;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private static int[] readInts(byte[] d, int off, int count) {
        int n = Math.max(0, Math.min(count, (d.length - off) / 4));
        int[] r = new int[n];
        for (int i = 0; i < n; i++) r[i] = i32(d, off + i * 4);
        return r;
    }

    private static Result decodeAni(byte[] d) {
        int dispRate = 6;
        int[] rates = null;
        int[] seq = null;
        List<Frame> frames = new ArrayList<Frame>();

        int pos = 12;
        while (pos + 8 <= d.length) {
            int size = i32(d, pos + 4);
            int body = pos + 8;
            if (size < 0 || size > d.length - body) size = d.length - body;

            if (tag(d, pos, "anih")) {
                if (size >= 36) dispRate = i32(d, body + 28);
            } else if (tag(d, pos, "rate")) {
                rates = readInts(d, body, size / 4);
            } else if (tag(d, pos, "seq ")) {
                seq = readInts(d, body, size / 4);
            } else if (tag(d, pos, "LIST") && size >= 4 && tag(d, body, "fram")) {
                int listEnd = body + size;
                int p = body + 4;
                while (p + 8 <= listEnd) {
                    int s2 = i32(d, p + 4);
                    int b2 = p + 8;
                    if (s2 < 0 || s2 > listEnd - b2) s2 = listEnd - b2;
                    if (tag(d, p, "icon")) {
                        Frame f = decodeIco(d, b2, s2);
                        if (f == null) return null;
                        frames.add(f);
                    }
                    p = b2 + s2 + (s2 & 1);
                }
            }
            pos = body + size + (size & 1);
        }

        if (frames.isEmpty()) return null;

        boolean hasSeq = seq != null && seq.length > 0;
        int steps = hasSeq ? seq.length : frames.size();
        Result r = new Result();
        r.stepBitmaps = new Bitmap[steps];
        r.stepDelays = new int[steps];
        for (int i = 0; i < steps; i++) {
            int fi = hasSeq ? seq[i] : i;
            if (fi < 0 || fi >= frames.size()) fi = 0;
            r.stepBitmaps[i] = frames.get(fi).bmp;
            int jif = (rates != null && i < rates.length) ? rates[i] : dispRate;
            if (jif < 1) jif = 1;
            long ms = (long) jif * 1000L / 60L;
            r.stepDelays[i] = (int) Math.max(20L, Math.min(5000L, ms));
        }
        int f0 = (hasSeq && seq[0] >= 0 && seq[0] < frames.size()) ? seq[0] : 0;
        r.hotX = frames.get(f0).hotX;
        r.hotY = frames.get(f0).hotY;
        return r;
    }

    private static Frame decodeIco(byte[] d, int off, int len) {
        if (len < 22) return null;
        int type = u16(d, off + 2);
        int count = u16(d, off + 4);
        if ((type != 1 && type != 2) || count < 1) return null;

        int best = -1;
        long bestArea = -1;
        for (int i = 0; i < count; i++) {
            int e = off + 6 + i * 16;
            if (e + 16 > off + len) break;
            int w = d[e] & 0xFF;
            if (w == 0) w = 256;
            int h = d[e + 1] & 0xFF;
            if (h == 0) h = 256;
            long area = (long) w * h;
            if (area > bestArea) {
                bestArea = area;
                best = e;
            }
        }
        if (best < 0) return null;

        int dataSize = i32(d, best + 8);
        int dataOff = off + i32(d, best + 12);
        if (dataOff < 0 || dataOff >= d.length) return null;
        if (dataSize <= 0 || dataSize > d.length - dataOff) dataSize = d.length - dataOff;

        Bitmap bmp;
        if (dataSize > 8 && (d[dataOff] & 0xFF) == 0x89 && d[dataOff + 1] == 'P'
                && d[dataOff + 2] == 'N' && d[dataOff + 3] == 'G') {
            bmp = BitmapFactory.decodeByteArray(d, dataOff, dataSize);
        } else {
            bmp = decodeDib(d, dataOff, dataSize);
        }
        if (bmp == null) return null;

        Frame f = new Frame();
        f.bmp = bmp;
        if (type == 2) {
            f.hotX = u16(d, best + 4);
            f.hotY = u16(d, best + 6);
        }
        return f;
    }

    private static Bitmap decodeDib(byte[] d, int start, int size) {
        int hdr = i32(d, start);
        if (hdr < 40) return null;
        int w = i32(d, start + 4);
        int hAll = i32(d, start + 8);
        int bpp = u16(d, start + 14);
        int comp = i32(d, start + 16);
        int colorsUsed = i32(d, start + 32);
        int h = hAll / 2;
        if (w <= 0 || h <= 0 || w > 1024 || h > 1024) return null;
        if (comp != 0 && comp != 3) return null;

        int palCount = 0;
        if (bpp <= 8) palCount = colorsUsed > 0 ? colorsUsed : (1 << bpp);
        int palOff = start + hdr;
        int pixOff = palOff + palCount * 4;
        if (comp == 3 && hdr == 40) pixOff += 12;
        int stride = ((w * bpp + 31) / 32) * 4;
        int maskStride = ((w + 31) / 32) * 4;
        int maskOff = pixOff + stride * h;
        boolean hasMask = maskOff + maskStride * h <= start + size;

        int[] pal = new int[palCount];
        for (int i = 0; i < palCount; i++) {
            int o = palOff + i * 4;
            pal[i] = 0xFF000000 | ((d[o + 2] & 0xFF) << 16) | ((d[o + 1] & 0xFF) << 8) | (d[o] & 0xFF);
        }

        int[] px = new int[w * h];
        boolean anyAlpha = false;
        for (int y = 0; y < h; y++) {
            int row = pixOff + (h - 1 - y) * stride;
            for (int x = 0; x < w; x++) {
                int color;
                if (bpp == 32) {
                    int o = row + x * 4;
                    int a = d[o + 3] & 0xFF;
                    if (a != 0) anyAlpha = true;
                    color = (a << 24) | ((d[o + 2] & 0xFF) << 16) | ((d[o + 1] & 0xFF) << 8) | (d[o] & 0xFF);
                } else if (bpp == 24) {
                    int o = row + x * 3;
                    color = 0xFF000000 | ((d[o + 2] & 0xFF) << 16) | ((d[o + 1] & 0xFF) << 8) | (d[o] & 0xFF);
                } else if (bpp == 8) {
                    int idx = d[row + x] & 0xFF;
                    color = idx < palCount ? pal[idx] : 0xFF000000;
                } else if (bpp == 4) {
                    int v = d[row + (x >> 1)] & 0xFF;
                    int idx = (x & 1) == 0 ? (v >> 4) : (v & 0x0F);
                    color = idx < palCount ? pal[idx] : 0xFF000000;
                } else if (bpp == 1) {
                    int v = d[row + (x >> 3)] & 0xFF;
                    int idx = (v >> (7 - (x & 7))) & 1;
                    color = idx < palCount ? pal[idx] : 0xFF000000;
                } else {
                    return null;
                }
                px[y * w + x] = color;
            }
        }

        boolean alpha32 = (bpp == 32 && anyAlpha);
        if (!alpha32) {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    int i = y * w + x;
                    boolean transparent = false;
                    if (hasMask) {
                        int mo = maskOff + (h - 1 - y) * maskStride + (x >> 3);
                        transparent = ((d[mo] >> (7 - (x & 7))) & 1) != 0;
                    }
                    if (transparent) px[i] = 0;
                    else px[i] |= 0xFF000000;
                }
            }
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888);
    }
}
