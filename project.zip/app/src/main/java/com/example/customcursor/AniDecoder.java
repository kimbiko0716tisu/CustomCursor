package com.example.customcursor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class AniDecoder {

    public static class AniFrame {
        public Bitmap bitmap;
        public int delay; // milliseconds
    }

    public static List<AniFrame> decode(InputStream inputStream) {
        List<AniFrame> frames = new ArrayList<>();
        try {
            byte[] bytes = readAllBytes(inputStream);
            
            // Check RIFF / ACON header for animated cursor format
            if (bytes.length > 12 && 
                bytes[0] == 'R' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == 'F' &&
                bytes[8] == 'A' && bytes[9] == 'C' && bytes[10] == 'O' && bytes[11] == 'N') {
                
                List<byte[]> iconChunks = extractIconChunks(bytes);
                List<Integer> rates = extractRates(bytes, iconChunks.size());

                for (int i = 0; i < iconChunks.size(); i++) {
                    byte[] iconBytes = iconChunks.get(i);
                    Bitmap bmp = BitmapFactory.decodeByteArray(iconBytes, 0, iconBytes.length);
                    if (bmp != null) {
                        AniFrame frame = new AniFrame();
                        frame.bitmap = bmp;
                        int jiffie = (i < rates.size()) ? rates.get(i) : 60;
                        frame.delay = Math.max(20, (int)(jiffie * 16.6667));
                        frames.add(frame);
                    }
                }
            }
            
            // Fallback for standard PNG/JPG or single cursor images
            if (frames.isEmpty()) {
                Bitmap singleBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (singleBitmap != null) {
                    AniFrame frame = new AniFrame();
                    frame.bitmap = singleBitmap;
                    frame.delay = 100;
                    frames.add(frame);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return frames;
    }

    private static List<byte[]> extractIconChunks(byte[] data) {
        List<byte[]> icons = new ArrayList<>();
        int i = 12;
        while (i < data.length - 4) {
            if (i + 4 <= data.length && 
                data[i] == 'i' && data[i+1] == 'c' && data[i+2] == 'o' && data[i+3] == 'n') {
                if (i + 8 <= data.length) {
                    int length = ByteBuffer.wrap(data, i + 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    if (i + 8 + length <= data.length) {
                        byte[] iconData = new byte[length];
                        System.arraycopy(data, i + 8, iconData, 0, length);
                        icons.add(iconData);
                    }
                }
            }
            i++;
        }
        return icons;
    }

    private static List<Integer> extractRates(byte[] data, int frameCount) {
        List<Integer> rates = new ArrayList<>();
        for (int i = 12; i < data.length - 4; i++) {
            if (data[i] == 'r' && data[i+1] == 'a' && data[i+2] == 't' && data[i+3] == 'e') {
                if (i + 8 <= data.length) {
                    int length = ByteBuffer.wrap(data, i + 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    int dataStart = i + 8;
                    for (int r = 0; r < length / 4 && r < frameCount; r++) {
                        if (dataStart + (r + 1) * 4 <= data.length) {
                            int rateVal = ByteBuffer.wrap(data, dataStart + r * 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                            rates.add(rateVal);
                        }
                    }
                }
            }
        }
        return rates;
    }

    private static byte[] readAllBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int nRead;
        byte[] data = new byte[16384];
        while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        return buffer.toByteArray();
    }
}
