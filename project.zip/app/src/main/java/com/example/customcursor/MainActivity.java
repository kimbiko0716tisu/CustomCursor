package com.example.customcursor;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_IMAGE = 1;

    private SharedPreferences prefs;
    private float density = 1f;
    private TextView statusText;
    private ImageView preview;
    private final List<Runnable> syncers = new ArrayList<Runnable>();

    private int dp(float v) {
        return Math.round(v * density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = Prefs.get(this);
        density = getResources().getDisplayMetrics().density;

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(32));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("CustomCursor");
        title.setTextSize(24);
        root.addView(title);

        statusText = new TextView(this);
        statusText.setTextSize(16);
        statusText.setPadding(0, dp(8), 0, dp(8));
        root.addView(statusText);

        Button open = new Button(this);
        open.setText("접근성 설정 열기");
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(open);

        addSwitch(root, "커서 표시", Prefs.CURSOR_VISIBLE, true);
        addSwitch(root, "터치패드 사용", Prefs.PAD_ENABLED, true);
        addSwitch(root, "마우스 모드 (실험 기능)", Prefs.MOUSE_MODE, false);

        TextView hint = new TextView(this);
        hint.setText("마우스 모드를 켜면 블루투스 마우스 움직임을 따라 내 커서가 움직입니다. "
                + "손가락으로 화면을 누르면 자동으로 꺼집니다.");
        hint.setTextSize(13);
        root.addView(hint);

        addSeek(root, "커서 크기", 16, 128, Prefs.SIZE_DP, 32, false, "dp");
        addSeek(root, "투명도", 20, 100, Prefs.OPACITY, 100, false, "%");
        addSeek(root, "커서 속도", 5, 40, Prefs.SPEED, 25, true, "배");
        addSeek(root, "터치패드 높이", 100, 320, Prefs.PAD_HEIGHT_DP, 180, false, "dp");

        TextView imgTitle = new TextView(this);
        imgTitle.setText("커서 모양");
        imgTitle.setTextSize(18);
        imgTitle.setPadding(0, dp(24), 0, dp(8));
        root.addView(imgTitle);

        preview = new ImageView(this);
        preview.setBackgroundColor(0xFF888888);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(96), dp(96));
        plp.gravity = Gravity.START;
        root.addView(preview, plp);

        Button pick = new Button(this);
        pick.setText("커서 이미지 고르기 (PNG 추천)");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i, REQ_IMAGE);
            }
        });
        root.addView(pick);

        Button reset = new Button(this);
        reset.setText("기본 커서로 되돌리기");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new File(getFilesDir(), Prefs.IMAGE_FILE).delete();
                prefs.edit().putLong(Prefs.IMAGE_VERSION, System.currentTimeMillis()).apply();
                updatePreview();
            }
        });
        root.addView(reset);

        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        statusText.setText(serviceEnabled()
                ? "서비스: 켜짐"
                : "서비스: 꺼짐 (아래 버튼으로 접근성 설정에서 CustomCursor를 켜 주세요)");
        for (Runnable r : syncers) r.run();
        updatePreview();
    }

    private boolean serviceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.contains(getPackageName() + "/");
    }

    private void addSwitch(LinearLayout root, String label, final String key, final boolean def) {
        final Switch s = new Switch(this);
        s.setText(label);
        s.setTextSize(16);
        s.setChecked(prefs.getBoolean(key, def));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(key, checked).apply();
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        root.addView(s, lp);
        syncers.add(new Runnable() {
            @Override
            public void run() {
                s.setChecked(prefs.getBoolean(key, def));
            }
        });
    }

    private String seekLabel(String label, int v, boolean tenths, String unit) {
        return label + ": " + (tenths ? String.valueOf(v / 10f) : String.valueOf(v)) + unit;
    }

    private void addSeek(LinearLayout root, final String label, final int min, int max,
                         final String key, int def, final boolean tenths, final String unit) {
        final TextView t = new TextView(this);
        t.setTextSize(15);
        t.setPadding(0, dp(16), 0, 0);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        int cur = prefs.getInt(key, def);
        sb.setProgress(cur - min);
        t.setText(seekLabel(label, cur, tenths, unit));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = p + min;
                t.setText(seekLabel(label, v, tenths, unit));
                if (fromUser) prefs.edit().putInt(key, v).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        root.addView(t);
        root.addView(sb);
    }

    private void updatePreview() {
        File f = new File(getFilesDir(), Prefs.IMAGE_FILE);
        Bitmap bmp = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (bmp != null) preview.setImageBitmap(bmp);
        else preview.setImageResource(R.drawable.cursor);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMAGE && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            saveCursorImage(data.getData());
        }
    }

    private void saveCursorImage(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            InputStream in1 = getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in1, null, bounds);
            if (in1 != null) in1.close();

            int sample = 1;
            while (bounds.outWidth / sample > 512 || bounds.outHeight / sample > 512) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            InputStream in2 = getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in2, null, opts);
            if (in2 != null) in2.close();
            if (bmp == null) {
                Toast.makeText(this, "이미지를 불러오지 못했어요", Toast.LENGTH_SHORT).show();
                return;
            }

            FileOutputStream out = new FileOutputStream(new File(getFilesDir(), Prefs.IMAGE_FILE));
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();

            prefs.edit().putLong(Prefs.IMAGE_VERSION, System.currentTimeMillis()).apply();
            updatePreview();
            Toast.makeText(this, "커서 이미지를 바꿨어요", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "이미지를 불러오지 못했어요", Toast.LENGTH_SHORT).show();
        }
    }
}
