package com.example.customcursor;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;

import java.io.InputStream;
import java.util.List;

public class CursorService extends AccessibilityService {

    private WindowManager windowManager;
    private View cursorView;
    private ImageView cursorImageView;
    private WindowManager.LayoutParams params;

    private List<AniDecoder.AniFrame> mAniFrames;
    private int mCurrentFrameIndex = 0;
    private Handler mAnimationHandler = new Handler(Looper.getMainLooper());
    private Runnable mAnimationRunnable = new Runnable() {
        @Override
        public void run() {
            if (mAniFrames != null && !mAniFrames.isEmpty()) {
                AniDecoder.AniFrame frame = mAniFrames.get(mCurrentFrameIndex);
                if (cursorImageView != null && frame.bitmap != null) {
                    cursorImageView.setImageBitmap(frame.bitmap);
                }
                mCurrentFrameIndex = (mCurrentFrameIndex + 1) % mAniFrames.size();
                mAnimationHandler.postDelayed(this, frame.delay);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        cursorView = LayoutInflater.from(this).inflate(R.layout.cursor, null);
        cursorImageView = cursorView.findViewById(R.id.cursorImageView);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 100;
        params.y = 100;

        windowManager.addView(cursorView, params);
    }

    public void loadCursorStream(InputStream inputStream, boolean isAni) {
        mAnimationHandler.removeCallbacks(mAnimationRunnable);
        mAniFrames = AniDecoder.decode(inputStream);
        mCurrentFrameIndex = 0;
        if (mAniFrames != null && !mAniFrames.isEmpty()) {
            mAnimationHandler.post(mAnimationRunnable);
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Handle touch / pointer events if needed to move cursor
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mAnimationHandler.removeCallbacks(mAnimationRunnable);
        if (cursorView != null && windowManager != null) {
            windowManager.removeView(cursorView);
        }
    }
}
