package com.example.customcursor;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

public class CursorService extends AccessibilityService {

    private static final int OVERLAY = WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY;
    private static final int BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    // ---- state (declared first so the lambdas below can use them) ----
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private SharedPreferences prefs;
    private boolean connected = false;
    private float density = 1f;
    private int screenW, screenH, touchSlop;

    private float cx, cy; // cursor hotspot (top-left of the image), screen pixels

    private View catcherView;
    private WindowManager.LayoutParams catcherParams;
    private ImageView cursorView;
    private WindowManager.LayoutParams cursorParams;
    private LinearLayout padView;
    private WindowManager.LayoutParams padParams;
    private TextView bubbleView;
    private WindowManager.LayoutParams bubbleParams;
    private int bubbleX = -1, bubbleY = -1;
    private boolean bubbleDragged = false;

    private float padLastX, padLastY, padDownX, padDownY;
    private long padDownTime;
    private boolean padMoved, padLongFired, padMulti;
    private float multiStartX, multiStartY, multiEndX, multiEndY;

    private float mouseDownX, mouseDownY;
    private long mouseDownTime;
    private boolean mouseDown = false;
    private long lastScrollTime = 0;

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshOverlays();
        }
    };

    private final Runnable padLongPress = new Runnable() {
        @Override
        public void run() {
            if (!padMoved && !padMulti) {
                padLongFired = true;
                dispatchStroke(cx, cy, cx, cy, 700);
            }
        }
    };

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences p, String key) {
                    scheduleRefresh();
                }
            };

    // ---- lifecycle ----
    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = Prefs.get(this);
        density = getResources().getDisplayMetrics().density;
        touchSlop = ViewConfiguration.get(this).getScaledTouchSlop();
        readScreenSize();
        cx = screenW / 2f;
        cy = screenH / 2f;
        bubbleX = screenW - dp(72);
        bubbleY = screenH - dp(160);
        connected = true;
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
        refreshOverlays();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (!connected) return;
        readScreenSize();
        cx = Math.min(cx, screenW - 1);
        cy = Math.min(cy, screenH - 1);
        bubbleX = Math.min(bubbleX, screenW - dp(60));
        bubbleY = Math.min(bubbleY, screenH - dp(60));
        scheduleRefresh();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        connected = false;
        handler.removeCallbacksAndMessages(null);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        if (wm != null) removeOverlays();
        return super.onUnbind(intent);
    }

    // ---- helpers ----
    private int dp(float v) {
        return Math.round(v * density);
    }

    private void readScreenSize() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    private GradientDrawable rounded(int color, float radiusDp) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }

    private float clampX(float x) {
        return Math.max(0, Math.min(x, screenW - 1));
    }

    private float clampY(float y) {
        return Math.max(0, Math.min(y, screenH - 1));
    }

    // ---- overlays ----
    private void scheduleRefresh() {
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, 80);
    }

    private void refreshOverlays() {
        if (!connected) return;
        removeOverlays();
        if (prefs.getBoolean(Prefs.MOUSE_MODE, false)) addCatcher();
        if (prefs.getBoolean(Prefs.CURSOR_VISIBLE, true)) addCursor();
        if (prefs.getBoolean(Prefs.PAD_ENABLED, true)) {
            if (prefs.getBoolean(Prefs.PAD_EXPANDED, true)) addPad();
            else addBubble();
        }
    }

    private void removeOverlays() {
        removeQuietly(catcherView);
        catcherView = null;
        removeQuietly(cursorView);
        cursorView = null;
        removeQuietly(padView);
        padView = null;
        removeQuietly(bubbleView);
        bubbleView = null;
    }

    private void removeQuietly(View v) {
        if (v == null) return;
        try {
            wm.removeView(v);
        } catch (Exception ignored) {
        }
    }

    private void addCursor() {
        int size = dp(prefs.getInt(Prefs.SIZE_DP, 32));
        cursorView = new ImageView(this);
        cursorView.setScaleType(ImageView.ScaleType.FIT_START);
        File f = new File(getFilesDir(), Prefs.IMAGE_FILE);
        Bitmap bmp = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (bmp != null) cursorView.setImageBitmap(bmp);
        else cursorView.setImageResource(R.drawable.cursor);
        cursorView.setAlpha(prefs.getInt(Prefs.OPACITY, 100) / 100f);

        cursorParams = new WindowManager.LayoutParams(size, size, OVERLAY,
                BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        cursorParams.gravity = Gravity.TOP | Gravity.START;
        cursorParams.x = Math.round(cx);
        cursorParams.y = Math.round(cy);
        wm.addView(cursorView, cursorParams);
    }

    private void moveCursorTo(float x, float y) {
        cx = clampX(x);
        cy = clampY(y);
        if (cursorView != null) {
            cursorParams.x = Math.round(cx);
            cursorParams.y = Math.round(cy);
            try {
                wm.updateViewLayout(cursorView, cursorParams);
            } catch (Exception ignored) {
            }
        }
    }

    private TextView makeButton(String label, View.OnClickListener listener) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setBackground(rounded(0x55FFFFFF, 10));
        t.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
        lp.rightMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private void addPad() {
        int h = dp(prefs.getInt(Prefs.PAD_HEIGHT_DP, 180));
        int w = (int) Math.min(screenW * 0.7f, dp(560));

        padView = new LinearLayout(this);
        padView.setOrientation(LinearLayout.VERTICAL);
        padView.setBackground(rounded(0xB3202020, 16));
        padView.setPadding(dp(8), dp(8), dp(8), dp(8));

        boolean mouseMode = prefs.getBoolean(Prefs.MOUSE_MODE, false);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(makeButton("뒤로", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGlobalAction(GLOBAL_ACTION_BACK);
            }
        }));
        row.addView(makeButton("홈", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGlobalAction(GLOBAL_ACTION_HOME);
            }
        }));
        row.addView(makeButton("최근", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performGlobalAction(GLOBAL_ACTION_RECENTS);
            }
        }));
        row.addView(makeButton(mouseMode ? "마우스 끄기" : "마우스 켜기", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean now = prefs.getBoolean(Prefs.MOUSE_MODE, false);
                prefs.edit().putBoolean(Prefs.MOUSE_MODE, !now).apply();
            }
        }));
        row.addView(makeButton("접기", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prefs.edit().putBoolean(Prefs.PAD_EXPANDED, false).apply();
            }
        }));
        padView.addView(row, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));

        TextView area = new TextView(this);
        area.setText("터치패드");
        area.setTextColor(0x88FFFFFF);
        area.setGravity(Gravity.CENTER);
        area.setBackground(rounded(0x40FFFFFF, 12));
        area.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                return onPadTouch(e);
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
        lp.topMargin = dp(8);
        padView.addView(area, lp);

        padParams = new WindowManager.LayoutParams(w, h, OVERLAY, BASE_FLAGS,
                PixelFormat.TRANSLUCENT);
        padParams.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        padParams.y = dp(56);
        wm.addView(padView, padParams);
    }

    private void addBubble() {
        bubbleView = new TextView(this);
        bubbleView.setText("커서");
        bubbleView.setTextColor(Color.WHITE);
        bubbleView.setTextSize(12);
        bubbleView.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        gd.setColor(0xCC3366FF);
        bubbleView.setBackground(gd);

        bubbleParams = new WindowManager.LayoutParams(dp(52), dp(52), OVERLAY, BASE_FLAGS,
                PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = bubbleX;
        bubbleParams.y = bubbleY;

        final float[] st = new float[4];
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: {
                        st[0] = e.getRawX();
                        st[1] = e.getRawY();
                        st[2] = bubbleParams.x;
                        st[3] = bubbleParams.y;
                        bubbleDragged = false;
                        return true;
                    }
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - st[0];
                        float dy = e.getRawY() - st[1];
                        if (Math.hypot(dx, dy) > touchSlop) bubbleDragged = true;
                        if (bubbleDragged) {
                            bubbleX = (int) (st[2] + dx);
                            bubbleY = (int) (st[3] + dy);
                            bubbleParams.x = bubbleX;
                            bubbleParams.y = bubbleY;
                            try {
                                wm.updateViewLayout(bubbleView, bubbleParams);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        if (!bubbleDragged) {
                            prefs.edit().putBoolean(Prefs.PAD_EXPANDED, true).apply();
                        }
                        return true;
                    }
                    default:
                        return true;
                }
            }
        });
        wm.addView(bubbleView, bubbleParams);
    }

    // ---- touchpad ----
    private float avgX(MotionEvent e) {
        float s = 0;
        for (int i = 0; i < e.getPointerCount(); i++) s += e.getX(i);
        return s / e.getPointerCount();
    }

    private float avgY(MotionEvent e) {
        float s = 0;
        for (int i = 0; i < e.getPointerCount(); i++) s += e.getY(i);
        return s / e.getPointerCount();
    }

    private boolean onPadTouch(MotionEvent e) {
        float speed = prefs.getInt(Prefs.SPEED, 25) / 10f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                padLastX = e.getX();
                padLastY = e.getY();
                padDownX = padLastX;
                padDownY = padLastY;
                padDownTime = e.getEventTime();
                padMoved = false;
                padLongFired = false;
                padMulti = false;
                handler.postDelayed(padLongPress, 600);
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN: {
                padMulti = true;
                handler.removeCallbacks(padLongPress);
                multiStartX = avgX(e);
                multiStartY = avgY(e);
                multiEndX = multiStartX;
                multiEndY = multiStartY;
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (padMulti) {
                    multiEndX = avgX(e);
                    multiEndY = avgY(e);
                    return true;
                }
                float dx = e.getX() - padLastX;
                float dy = e.getY() - padLastY;
                padLastX = e.getX();
                padLastY = e.getY();
                if (!padMoved && Math.hypot(e.getX() - padDownX, e.getY() - padDownY) > touchSlop) {
                    padMoved = true;
                    handler.removeCallbacks(padLongPress);
                }
                if (padMoved) moveCursorTo(cx + dx * speed, cy + dy * speed);
                return true;
            }
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(padLongPress);
                if (padMulti) {
                    float sx = multiEndX - multiStartX;
                    float sy = multiEndY - multiStartY;
                    float dist = (float) Math.hypot(sx, sy);
                    if (dist < touchSlop * 2) {
                        if (e.getEventTime() - padDownTime < 400) {
                            performGlobalAction(GLOBAL_ACTION_BACK);
                        }
                    } else {
                        float len = dp(240);
                        float ex = cx;
                        float ey = cy;
                        if (Math.abs(sy) >= Math.abs(sx)) ey = cy + (sy > 0 ? len : -len);
                        else ex = cx + (sx > 0 ? len : -len);
                        dispatchStroke(cx, cy, clampX(ex), clampY(ey), 250);
                    }
                    padMulti = false;
                } else if (!padMoved && !padLongFired) {
                    dispatchStroke(cx, cy, cx, cy, 50);
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL: {
                handler.removeCallbacks(padLongPress);
                return true;
            }
            default:
                return true;
        }
    }

    // ---- mouse mode ----
    private void addCatcher() {
        catcherView = new View(this);
        catcherParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT);
        catcherParams.gravity = Gravity.TOP | Gravity.START;
        catcherView.setOnHoverListener(new View.OnHoverListener() {
            @Override
            public boolean onHover(View v, MotionEvent e) {
                onMouseMotion(e);
                return true;
            }
        });
        catcherView.setOnGenericMotionListener(new View.OnGenericMotionListener() {
            @Override
            public boolean onGenericMotion(View v, MotionEvent e) {
                onMouseMotion(e);
                return true;
            }
        });
        catcherView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                onCatcherTouch(e);
                return true;
            }
        });
        wm.addView(catcherView, catcherParams);
    }

    private void setCatcherTouchable(boolean touchable) {
        if (catcherView == null || catcherParams == null) return;
        catcherParams.flags = touchable
                ? BASE_FLAGS
                : (BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
        try {
            wm.updateViewLayout(catcherView, catcherParams);
        } catch (Exception ignored) {
        }
    }

    private void onMouseMotion(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_HOVER_ENTER:
            case MotionEvent.ACTION_HOVER_MOVE:
                moveCursorTo(e.getRawX(), e.getRawY());
                break;
            case MotionEvent.ACTION_SCROLL: {
                moveCursorTo(e.getRawX(), e.getRawY());
                float v = e.getAxisValue(MotionEvent.AXIS_VSCROLL);
                float h = e.getAxisValue(MotionEvent.AXIS_HSCROLL);
                long now = System.currentTimeMillis();
                if ((v != 0 || h != 0) && now - lastScrollTime > 250) {
                    lastScrollTime = now;
                    float ex = clampX(cx - h * dp(120));
                    float ey = clampY(cy + v * dp(120));
                    dispatchStroke(cx, cy, ex, ey, 200);
                }
                break;
            }
            default:
                break;
        }
    }

    private void onCatcherTouch(MotionEvent e) {
        boolean isMouse = (e.getSource() & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE;
        if (!isMouse) {
            // A real finger touched the screen: leave mouse mode so fingers work again.
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                final float x = e.getRawX();
                final float y = e.getRawY();
                prefs.edit().putBoolean(Prefs.MOUSE_MODE, false).apply();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dispatchStroke(x, y, x, y, 50);
                    }
                }, 300);
            }
            return;
        }

        float x = e.getRawX();
        float y = e.getRawY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                moveCursorTo(x, y);
                if ((e.getButtonState() & MotionEvent.BUTTON_SECONDARY) != 0) {
                    performGlobalAction(GLOBAL_ACTION_BACK);
                    mouseDown = false;
                    return;
                }
                mouseDown = true;
                mouseDownX = x;
                mouseDownY = y;
                mouseDownTime = e.getEventTime();
                break;
            case MotionEvent.ACTION_MOVE:
                moveCursorTo(x, y);
                break;
            case MotionEvent.ACTION_UP: {
                moveCursorTo(x, y);
                if (!mouseDown) return;
                mouseDown = false;
                long dur = e.getEventTime() - mouseDownTime;
                float moved = (float) Math.hypot(x - mouseDownX, y - mouseDownY);
                if (moved < touchSlop) {
                    dispatchStroke(mouseDownX, mouseDownY, mouseDownX, mouseDownY,
                            dur > 500 ? 700 : 50);
                } else {
                    dispatchStroke(mouseDownX, mouseDownY, x, y,
                            Math.max(150, Math.min(dur, 3000)));
                }
                break;
            }
            default:
                break;
        }
    }

    // ---- gestures ----
    private void dispatchStroke(float x1, float y1, float x2, float y2, long duration) {
        Path path = new Path();
        path.moveTo(x1, y1);
        if (x1 != x2 || y1 != y2) path.lineTo(x2, y2);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, Math.max(1, duration));
        final GestureDescription gesture =
                new GestureDescription.Builder().addStroke(stroke).build();

        final boolean needPassThrough = catcherView != null;
        if (needPassThrough) setCatcherTouchable(false);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                boolean ok = dispatchGesture(gesture, new GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription g) {
                        if (needPassThrough) setCatcherTouchable(true);
                    }

                    @Override
                    public void onCancelled(GestureDescription g) {
                        if (needPassThrough) setCatcherTouchable(true);
                    }
                }, handler);
                if (!ok && needPassThrough) setCatcherTouchable(true);
            }
        }, needPassThrough ? 80 : 0);
    }
}
