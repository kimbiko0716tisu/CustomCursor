package com.example.customcursor;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.ImageView;

public class CursorService extends AccessibilityService {
    private WindowManager windowManager;
    private ImageView cursorView;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        cursorView = new ImageView(this);
        cursorView.setImageResource(R.drawable.cursor);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                96, 96,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 500;
        params.y = 500;

        windowManager.addView(cursorView, params);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (cursorView != null) {
            windowManager.removeView(cursorView);
            cursorView = null;
        }
        return super.onUnbind(intent);
    }
}
