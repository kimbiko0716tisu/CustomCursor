# 안드로이드 마우스 커서 앱 .ani 파일 지원 가이드

1. AniDecoder.java 파일을 프로젝트의 `com/example/customcursor/` 패키지 경로에 교체하거나 추가합니다.
2. CursorService.java 파일에 애니메이션 루프 타이머 및 프레임 전환 로직을 적용합니다.
