package com.example.customcursor;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class AniDecoder {

    public static class AniFrame {
        public Bitmap bitmap;
        public int delay; // milliseconds
    }

    public static List<AniFrame> decode(InputStream inputStream) {
        List<AniFrame> frames = new ArrayList<>();
        try {
            byte[] bytes = readAllBytes(inputStream);
            
            // Basic RIFF/ANI parser logic
            // An ANI file is a RIFF file with 'ACON' form type.
            if (bytes.length > 12 && 
                bytes[0] == 'R' && bytes[1] == 'I' && bytes[2] == 'F' && bytes[3] == 'F' &&
                bytes[8] == 'A' && bytes[9] == 'C' && bytes[10] == 'O' && bytes[11] == 'N') {
                
                // Parse chunks to find 'rate' and individual icon/cur frames ('icon' or 'fram' chunks)
                // For robustness and fallback: we can scan for ICO/CUR magic headers or extract sub-chunks.
                // Let's implement a robust sub-chunk scanner for 'ICON' / 'CUR ' or standard icon headers (0x00000100)
                
                List<byte[]> iconChunks = extractIconChunks(bytes);
                List<Integer> rates = extractRates(bytes, iconChunks.size());

                for (int i = 0; i < iconChunks.size(); i++) {
                    byte[] iconBytes = iconChunks.get(i);
                    Bitmap bmp = BitmapFactory.decodeByteArray(iconBytes, 0, iconBytes.length);
                    if (bmp != null) {
                        AniFrame frame = new AniFrame();
                        frame.bitmap = bmp;
                        // ANI rate is measured in jiffies (1/60th of a second). Convert to milliseconds: jiffies * (1000 / 60) ≈ jiffies * 16.67, or standard default 100ms
                        int jiffie = (i < rates.size()) ? rates.get(i) : 60;
                        frame.delay = Math.max(20, (int)(jiffie * 16.6667));
                        frames.add(frame);
                    }
                }
            }
            
            // Fallback if no frames were decoded via RIFF chunks (e.g. standard single image or unsupported variant)
            if (frames.isEmpty()) {
                Bitmap singleBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                if (singleBitmap != null) {
                    AniFrame frame = new AniFrame();
                    frame.bitmap = singleBitmap;
                    frame.delay = 100;
                    frames.add(frame);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return frames;
    }

    private static List<byte[]> extractIconChunks(byte[] data) {
        List<byte[]> icons = new ArrayList<>();
        // Search for CURS or ICON or standard ICO magic (Reserved: 2 bytes, Type: 2 bytes (1=ICO, 2=CUR), Count: 2 bytes)
        // Alternatively, scan for RIFF sub-chunks or icon headers in the byte array.
        int i = 12;
        while (i < data.length - 4) {
            // Check for 'icon' or 'data' or 'fram' chunk or standard ICO header (0, 0, 1, 0 or 0, 0, 2, 0)
            if (i + 4 <= data.length && 
                data[i] == 'i' && data[i+1] == 'c' && data[i+2] == 'o' && data[i+3] == 'n') {
                // Read chunk length
                if (i + 8 <= data.length) {
                    int length = ByteBuffer.wrap(data, i + 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    if (i + 8 + length <= data.length) {
                        byte[] iconData = new byte[length];
                        System.arraycopy(data, i + 8, iconData, 0, length);
                        icons.add(iconData);
                    }
                }
            }
            // Also check for raw ICO header pattern if chunk tags differ
            i++;
        }
        
        // If no specific 'icon' chunks found, search for standard ICO headers (0x00 00 01 00 or 0x00 00 02 00) inside the file
        if (icons.isEmpty()) {
            for (int idx = 0; idx < data.length - 4; idx++) {
                if (data[idx] == 0 && data[idx+1] == 0 && (data[idx+2] == 1 || data[idx+2] == 2) && data[idx+3] == 0) {
                    // Found potential icon start. Look ahead or take till next or end.
                    // For simplicity in a single embedded cursor container, let's grab from idx to end or next header.
                    // Or let standard BitmapFactory handle if it's treated as an image container.
                }
            }
        }
        
        return icons;
    }

    private static List<Integer> extractRates(byte[] data, int frameCount) {
        List<Integer> rates = new ArrayList<>();
        // Look for 'rate' chunk in ANI file
        for (int i = 12; i < data.length - 4; i++) {
            if (data[i] == 'r' && data[i+1] == 'a' && data[i+2] == 't' && data[i+3] == 'e') {
                if (i + 8 <= data.length) {
                    int length = ByteBuffer.wrap(data, i + 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                    int dataStart = i + 8;
                    for (int r = 0; r < length / 4 && r < frameCount; r++) {
                        if (dataStart + (r + 1) * 4 <= data.length) {
                            int rateVal = ByteBuffer.wrap(data, dataStart + r * 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
                            rates.add(rateVal);
                        }
                    }
                }
            }
        }
        return rates;
    }

    private static byte[] readAllBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int nRead;
        byte[] data = new byte[16384];
        while ((nRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, nRead);
        }
        return buffer.toByteArray();
    }
}
